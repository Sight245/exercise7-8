# scrumboard-django

### WS-Exercise 8
