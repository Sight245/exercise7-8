# django - scrumboard - rest api

### WS -  Exercise 7
